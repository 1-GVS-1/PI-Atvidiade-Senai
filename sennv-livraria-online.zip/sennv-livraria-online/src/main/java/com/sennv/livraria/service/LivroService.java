package com.sennv.livraria.service;

import com.sennv.livraria.entity.Livro;
import com.sennv.livraria.repository.LivroRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class LivroService {
    
    private final LivroRepository livroRepository;
    
    public List<Livro> listarTodos() {
        return livroRepository.findByAtivoTrueOrderByDataCriacaoDesc();
    }
    
    public List<Livro> listarDestaque() {
        return livroRepository.findDestaque();
    }
    
    public Optional<Livro> obterPorId(Long id) {
        return livroRepository.findById(id);
    }
    
    public Livro salvar(Livro livro) {
        return livroRepository.save(livro);
    }
    
    public void deletar(Long id) {
        livroRepository.deleteById(id);
    }
    
    public List<Livro> buscar(String termo) {
        if (termo == null || termo.trim().isEmpty()) {
            return listarTodos();
        }
        return livroRepository.buscarPorTermo(termo);
    }
}
