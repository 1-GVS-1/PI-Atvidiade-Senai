package com.sennv.livraria.repository;

import com.sennv.livraria.entity.Livro;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface LivroRepository extends JpaRepository<Livro, Long> {
    
    List<Livro> findByAtivoTrue();
    
    List<Livro> findByAtivoTrueOrderByDataCriacaoDesc();
    
    @Query("SELECT l FROM Livro l WHERE l.ativo = true AND (l.titulo LIKE %:termo% OR l.autor LIKE %:termo%)")
    List<Livro> buscarPorTermo(@Param("termo") String termo);
    
    @Query("SELECT l FROM Livro l WHERE l.ativo = true ORDER BY l.dataCriacao DESC LIMIT 6")
    List<Livro> findDestaque();
}
