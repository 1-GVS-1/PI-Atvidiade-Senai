package com.sennv.livraria.controller;

import com.sennv.livraria.service.LivroService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/")
@RequiredArgsConstructor
public class HomeController {
    
    private final LivroService livroService;
    
    @GetMapping
    public String index(Model model) {
        model.addAttribute("livrosDestaque", livroService.listarDestaque());
        return "index";
    }
    
    @GetMapping("catalogo")
    public String catalogo(Model model) {
        model.addAttribute("livros", livroService.listarTodos());
        return "catalogo";
    }
}
