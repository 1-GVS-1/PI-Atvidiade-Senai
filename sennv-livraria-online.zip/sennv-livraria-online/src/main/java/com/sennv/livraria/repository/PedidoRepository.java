package com.sennv.livraria.repository;

import com.sennv.livraria.entity.Pedido;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface PedidoRepository extends JpaRepository<Pedido, Long> {
    
    Optional<Pedido> findByNumeroPedido(String numeroPedido);
    
    List<Pedido> findByNomeClienteContainingIgnoreCase(String nomeCliente);
    
    List<Pedido> findByStatus(Pedido.StatusPedido status);
    
    @Query("SELECT p FROM Pedido p ORDER BY p.dataCriacao DESC")
    List<Pedido> findAllOrderByDataCriacaoDesc();
    
    @Query("SELECT p FROM Pedido p WHERE p.nomeCliente LIKE %:termo% OR p.numeroPedido LIKE %:termo% OR p.emailCliente LIKE %:termo%")
    List<Pedido> buscarPorTermo(@Param("termo") String termo);
}
