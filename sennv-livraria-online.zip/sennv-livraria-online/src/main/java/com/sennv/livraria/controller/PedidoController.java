package com.sennv.livraria.controller;

import com.sennv.livraria.entity.ItemPedido;
import com.sennv.livraria.entity.Livro;
import com.sennv.livraria.entity.Pedido;
import com.sennv.livraria.service.LivroService;
import com.sennv.livraria.service.PedidoService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/pedidos")
@RequiredArgsConstructor
public class PedidoController {
    
    private final PedidoService pedidoService;
    private final LivroService livroService;
    
    @GetMapping
    public String listar(Model model, @RequestParam(required = false) String busca) {
        List<Pedido> pedidos;
        if (busca != null && !busca.trim().isEmpty()) {
            pedidos = pedidoService.buscar(busca);
            model.addAttribute("busca", busca);
        } else {
            pedidos = pedidoService.listarTodos();
        }
        model.addAttribute("pedidos", pedidos);
        return "pedidos/listar";
    }
    
    @GetMapping("/{id}")
    public String visualizar(@PathVariable Long id, Model model) {
        Optional<Pedido> pedido = pedidoService.obterPorId(id);
        if (pedido.isEmpty()) {
            return "redirect:/pedidos";
        }
        model.addAttribute("pedido", pedido.get());
        return "pedidos/visualizar";
    }
    
    @GetMapping("/novo")
    public String novo(Model model) {
        model.addAttribute("livros", livroService.listarTodos());
        model.addAttribute("pedido", new Pedido());
        return "pedidos/novo";
    }
    
    @PostMapping
    public String criar(@ModelAttribute Pedido pedido, 
                       @RequestParam(required = false) Long[] livroIds,
                       @RequestParam(required = false) Integer[] quantidades) {
        
        if (livroIds != null && quantidades != null) {
            List<ItemPedido> itens = new ArrayList<>();
            BigDecimal total = BigDecimal.ZERO;
            
            for (int i = 0; i < livroIds.length; i++) {
                Optional<Livro> livro = livroService.obterPorId(livroIds[i]);
                if (livro.isPresent() && quantidades[i] > 0) {
                    ItemPedido item = new ItemPedido();
                    item.setLivro(livro.get());
                    item.setQuantidade(quantidades[i]);
                    item.setPrecoUnitario(livro.get().getPreco());
                    item.setSubtotal(livro.get().getPreco().multiply(new BigDecimal(quantidades[i])));
                    itens.add(item);
                    total = total.add(item.getSubtotal());
                }
            }
            
            if (!itens.isEmpty()) {
                pedido.setItens(itens);
                pedido.setTotalPedido(total);
                Pedido pedidoCriado = pedidoService.criar(pedido);
                return "redirect:/pedidos/" + pedidoCriado.getId();
            }
        }
        
        return "redirect:/pedidos/novo";
    }
    
    @PostMapping("/{id}/deletar")
    public String deletar(@PathVariable Long id) {
        pedidoService.deletar(id);
        return "redirect:/pedidos";
    }
    
    @PostMapping("/{id}/atualizar-status")
    public String atualizarStatus(@PathVariable Long id, @RequestParam Pedido.StatusPedido status) {
        Optional<Pedido> pedido = pedidoService.obterPorId(id);
        if (pedido.isPresent()) {
            Pedido p = pedido.get();
            p.setStatus(status);
            pedidoService.atualizar(p);
        }
        return "redirect:/pedidos/" + id;
    }
}
