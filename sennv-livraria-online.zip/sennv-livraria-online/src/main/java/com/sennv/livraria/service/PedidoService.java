package com.sennv.livraria.service;

import com.sennv.livraria.entity.ItemPedido;
import com.sennv.livraria.entity.Livro;
import com.sennv.livraria.entity.Pedido;
import com.sennv.livraria.repository.PedidoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class PedidoService {
    
    private final PedidoRepository pedidoRepository;
    private final LivroService livroService;
    
    public List<Pedido> listarTodos() {
        return pedidoRepository.findAllOrderByDataCriacaoDesc();
    }
    
    public Optional<Pedido> obterPorId(Long id) {
        return pedidoRepository.findById(id);
    }
    
    public Optional<Pedido> obterPorNumeroPedido(String numeroPedido) {
        return pedidoRepository.findByNumeroPedido(numeroPedido);
    }
    
    public Pedido criar(Pedido pedido) {
        // Gerar número único do pedido
        pedido.setNumeroPedido(gerarNumeroPedido());
        pedido.setStatus(Pedido.StatusPedido.PENDENTE);
        pedido.setDataCriacao(LocalDateTime.now());
        pedido.setDataAtualizacao(LocalDateTime.now());
        
        // Calcular total
        BigDecimal total = BigDecimal.ZERO;
        for (ItemPedido item : pedido.getItens()) {
            item.setPedido(pedido);
            total = total.add(item.getSubtotal());
        }
        pedido.setTotalPedido(total);
        
        return pedidoRepository.save(pedido);
    }
    
    public Pedido atualizar(Pedido pedido) {
        pedido.setDataAtualizacao(LocalDateTime.now());
        
        // Recalcular total
        BigDecimal total = BigDecimal.ZERO;
        for (ItemPedido item : pedido.getItens()) {
            total = total.add(item.getSubtotal());
        }
        pedido.setTotalPedido(total);
        
        return pedidoRepository.save(pedido);
    }
    
    public void deletar(Long id) {
        pedidoRepository.deleteById(id);
    }
    
    public List<Pedido> buscar(String termo) {
        if (termo == null || termo.trim().isEmpty()) {
            return listarTodos();
        }
        return pedidoRepository.buscarPorTermo(termo);
    }
    
    public List<Pedido> filtrarPorStatus(Pedido.StatusPedido status) {
        return pedidoRepository.findByStatus(status);
    }
    
    private String gerarNumeroPedido() {
        // Formato: YYYY-MM-DD-HHmmss-XXXXX
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
        String timestamp = LocalDateTime.now().format(formatter);
        int random = (int) (Math.random() * 10000);
        return String.format("PED-%s-%05d", timestamp, random);
    }
}
