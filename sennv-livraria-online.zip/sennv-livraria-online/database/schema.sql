-- =====================================================
-- SÉNNV - Sistema de Pedidos de Livros
-- Banco de Dados: sennv_livraria
-- =====================================================

-- Criar banco de dados
CREATE DATABASE IF NOT EXISTS sennv_livraria;
USE sennv_livraria;

-- =====================================================
-- Tabela: livros
-- =====================================================
CREATE TABLE IF NOT EXISTS livros (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(255) NOT NULL,
    autor VARCHAR(255) NOT NULL,
    descricao TEXT,
    preco DECIMAL(10, 2) NOT NULL,
    imagem_url VARCHAR(500),
    estoque INT NOT NULL DEFAULT 0,
    ativo BOOLEAN NOT NULL DEFAULT TRUE,
    data_criacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    data_atualizacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_ativo (ativo),
    INDEX idx_data_criacao (data_criacao)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- Tabela: pedidos
-- =====================================================
CREATE TABLE IF NOT EXISTS pedidos (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    numero_pedido VARCHAR(50) NOT NULL UNIQUE,
    nome_cliente VARCHAR(255) NOT NULL,
    email_cliente VARCHAR(255) NOT NULL,
    telefonecliente VARCHAR(20) NOT NULL,
    endereco TEXT,
    status ENUM('PENDENTE', 'CONFIRMADO', 'ENVIADO', 'ENTREGUE', 'CANCELADO') NOT NULL DEFAULT 'PENDENTE',
    total_pedido DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    data_criacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    data_atualizacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_numero_pedido (numero_pedido),
    INDEX idx_status (status),
    INDEX idx_data_criacao (data_criacao)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- Tabela: itens_pedido
-- =====================================================
CREATE TABLE IF NOT EXISTS itens_pedido (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    pedido_id BIGINT NOT NULL,
    livro_id BIGINT NOT NULL,
    quantidade INT NOT NULL,
    preco_unitario DECIMAL(10, 2) NOT NULL,
    subtotal DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (pedido_id) REFERENCES pedidos(id) ON DELETE CASCADE,
    FOREIGN KEY (livro_id) REFERENCES livros(id) ON DELETE RESTRICT,
    INDEX idx_pedido_id (pedido_id),
    INDEX idx_livro_id (livro_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- Inserção de Dados Iniciais - Livros
-- =====================================================

INSERT INTO livros (titulo, autor, descricao, preco, imagem_url, estoque, ativo) VALUES
('Gestão de Projetos', 'Carlos Silva', 'Aprenda as melhores práticas de gestão de projetos com metodologias ágeis e tradicionais.', 89.90, 'https://imgs.search.brave.com/snLmdKg5WkqcyXk4yRC6lfCSgTy7wXG3qVGwQghH5to/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly93d3cu/Zm0ycy5jb20uYnIv/c3RvcmFnZS9ibG9n/L2ltYWdlcy9nZXN0/YW8tcG9yLXByb2pl/dG9zLndlYnA', 50, TRUE),

('Java Programação', 'João Santos', 'Guia completo de programação em Java, desde conceitos básicos até padrões avançados.', 129.90, 'https://imgs.search.brave.com/onQrX0jAtj8JLuqp23GYeJb4tRkbXhKecVbMTU1RNiU/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly9pbWcu/ZnJlZXBpay5jb20v/Zm90b3MtcHJlbWl1/bS90ZXh0by1kYS1s/aW5ndWFnZW0tZGUt/cHJvZ3JhbWFjYW8t/amF2YV8yNzIzMDYt/MTMzLmpwZz9zZW10/PWFpc19pbmNvbWlu/ZyZ3PTc0MCZxPTgw', 35, TRUE),

('O Poder do Hábito', 'Charles Duhigg', 'Descubra como os hábitos funcionam e como transformá-los para melhorar sua vida.', 69.90, 'https://images.unsplash.com/photo-1455390582262-044cdead277a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80', 60, TRUE),

('Clean Code', 'Robert C. Martin', 'Escreva código limpo e profissional que seja fácil de manter e entender.', 99.90, 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80', 40, TRUE),

('Design Patterns', 'Gang of Four', 'Os 23 padrões de design fundamentais para desenvolvimento de software orientado a objetos.', 119.90, 'https://images.unsplash.com/photo-1516321318423-f06f70d504f0?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80', 25, TRUE),

('Estrutura de Dados', 'Mark Allen Weiss', 'Aprenda as principais estruturas de dados e seus algoritmos de manipulação.', 109.90, 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80', 45, TRUE),

('Banco de Dados SQL', 'Celko Joe', 'Domine SQL e otimize suas consultas para melhor desempenho em bancos de dados.', 99.90, 'https://images.unsplash.com/photo-1516321318423-f06f70d504f0?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80', 30, TRUE),

('Web Development com Spring', 'Ranga Karanam', 'Construa aplicações web modernas com Spring Boot, Thymeleaf e MySQL.', 139.90, 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80', 20, TRUE),

('Algoritmos Avançados', 'Thomas H. Cormen', 'Estude os algoritmos mais complexos e suas análises de complexidade.', 149.90, 'https://images.unsplash.com/photo-1516321318423-f06f70d504f0?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80', 15, TRUE),

('Segurança da Informação', 'Bruce Schneier', 'Proteja suas aplicações e dados contra ameaças de segurança.', 129.90, 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80', 28, TRUE);

-- =====================================================
-- Inserção de Dados Iniciais - Pedidos (Exemplo)
-- =====================================================

INSERT INTO pedidos (numero_pedido, nome_cliente, email_cliente, telefonecliente, endereco, status, total_pedido) VALUES
('PED-20250315120000-00001', 'João Silva', 'joao@example.com', '11999999999', 'Rua A, 123 - São Paulo, SP', 'PENDENTE', 199.80),
('PED-20250315110000-00002', 'Maria Santos', 'maria@example.com', '11988888888', 'Av. B, 456 - Rio de Janeiro, RJ', 'CONFIRMADO', 299.70),
('PED-20250315100000-00003', 'Pedro Costa', 'pedro@example.com', '11977777777', 'Rua C, 789 - Belo Horizonte, MG', 'ENVIADO', 159.80);

-- =====================================================
-- Inserção de Dados Iniciais - Itens do Pedido
-- =====================================================

INSERT INTO itens_pedido (pedido_id, livro_id, quantidade, preco_unitario, subtotal) VALUES
(1, 1, 2, 89.90, 179.80),
(1, 3, 1, 69.90, 69.90),
(2, 2, 2, 129.90, 259.80),
(2, 4, 1, 99.90, 99.90),
(3, 5, 1, 119.90, 119.90),
(3, 3, 1, 69.90, 69.90);

-- =====================================================
-- Verificação de Dados
-- =====================================================

SELECT COUNT(*) as total_livros FROM livros;
SELECT COUNT(*) as total_pedidos FROM pedidos;
SELECT COUNT(*) as total_itens FROM itens_pedido;
