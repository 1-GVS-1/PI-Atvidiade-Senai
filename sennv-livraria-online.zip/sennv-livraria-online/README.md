# SÉNNV - Sistema de Pedidos de Livros

## 📚 Descrição

SÉNNV é um **sistema de livraria online completo e funcional** desenvolvido com **Spring Boot**, **Thymeleaf** e **MySQL**. O sistema permite o gerenciamento completo de pedidos de livros, com funcionalidades de CRUD, carrinho de compras, catálogo dinâmico e relatórios de pedidos.

## ✨ Funcionalidades Principais

- ✅ **CRUD Completo de Pedidos**: Criar, listar, visualizar detalhes e deletar pedidos
- ✅ **Gerenciamento de Livros**: Cadastro de livros com título, autor, preço e imagem
- ✅ **Carrinho de Compras**: Adicionar/remover itens com cálculo automático de subtotais e total
- ✅ **Catálogo Dinâmico**: Página inicial com livros em destaque carregados do banco de dados
- ✅ **Finalização de Pedido**: Salvamento no banco de dados com geração de número único
- ✅ **Listagem de Pedidos**: Visualização de todos os pedidos com filtros e busca
- ✅ **Banco de Dados MySQL**: Schema completo com tabelas de livros, pedidos e itens
- ✅ **Interface Responsiva**: Design Bootstrap 5 profissional e responsivo
- ✅ **Atualização de Status**: Gerenciamento de status de pedidos (Pendente, Confirmado, Enviado, Entregue, Cancelado)

## 🛠️ Tecnologias Utilizadas

| Tecnologia | Versão | Descrição |
|-----------|--------|-----------|
| **Java** | 17 | Linguagem de programação |
| **Spring Boot** | 3.2.0 | Framework web |
| **Spring Data JPA** | 3.2.0 | ORM para persistência |
| **Thymeleaf** | 3.2.0 | Template engine |
| **MySQL** | 8.0+ | Banco de dados relacional |
| **Bootstrap** | 5.3.3 | Framework CSS |
| **Maven** | 3.8+ | Gerenciador de dependências |
| **Lombok** | 1.18+ | Redução de boilerplate |

## 📋 Pré-requisitos

Antes de executar o projeto, certifique-se de ter instalado:

- **Java 17+**: [Download Java](https://www.oracle.com/java/technologies/downloads/)
- **Maven 3.8+**: [Download Maven](https://maven.apache.org/download.cgi)
- **MySQL 8.0+**: [Download MySQL](https://dev.mysql.com/downloads/mysql/)
- **Git**: [Download Git](https://git-scm.com/)

## 🚀 Instalação e Execução

### 1. Clonar o Repositório

```bash
git clone https://github.com/seu-usuario/sennv-livraria-online.git
cd sennv-livraria-online
```

### 2. Criar o Banco de Dados

Abra o MySQL e execute o arquivo SQL para criar o banco de dados:

```bash
mysql -u root -p < database/schema.sql
```

Ou manualmente no MySQL:

```sql
CREATE DATABASE sennv_livraria;
USE sennv_livraria;
-- Execute o conteúdo do arquivo database/schema.sql
```

### 3. Configurar Conexão com Banco de Dados

Edite o arquivo `src/main/resources/application.properties`:

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/sennv_livraria?useSSL=false&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=sua_senha_aqui
```

### 4. Compilar o Projeto

```bash
mvn clean install
```

### 5. Executar a Aplicação

```bash
mvn spring-boot:run
```

Ou executar o JAR gerado:

```bash
java -jar target/livraria-online-1.0.0.jar
```

### 6. Acessar a Aplicação

Abra seu navegador e acesse:

```
http://localhost:8080
```

## 📁 Estrutura do Projeto

```
sennv-livraria-online/
├── src/
│   ├── main/
│   │   ├── java/com/sennv/livraria/
│   │   │   ├── controller/
│   │   │   │   ├── HomeController.java
│   │   │   │   └── PedidoController.java
│   │   │   ├── service/
│   │   │   │   ├── LivroService.java
│   │   │   │   └── PedidoService.java
│   │   │   ├── repository/
│   │   │   │   ├── LivroRepository.java
│   │   │   │   ├── PedidoRepository.java
│   │   │   │   └── ItemPedidoRepository.java
│   │   │   ├── entity/
│   │   │   │   ├── Livro.java
│   │   │   │   ├── Pedido.java
│   │   │   │   └── ItemPedido.java
│   │   │   └── LivrariApplication.java
│   │   └── resources/
│   │       ├── templates/
│   │       │   ├── index.html
│   │       │   ├── catalogo.html
│   │       │   └── pedidos/
│   │       │       ├── listar.html
│   │       │       ├── visualizar.html
│   │       │       └── novo.html
│   │       ├── static/css/
│   │       │   └── style.css
│   │       └── application.properties
│   └── test/
├── database/
│   └── schema.sql
├── pom.xml
├── README.md
└── .gitignore
```

## 🎯 Endpoints Principais

### Home e Catálogo

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| GET | `/` | Página inicial com livros em destaque |
| GET | `/catalogo` | Catálogo completo de livros |

### Pedidos

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| GET | `/pedidos` | Listar todos os pedidos |
| GET | `/pedidos?busca=termo` | Buscar pedidos por termo |
| GET | `/pedidos/{id}` | Visualizar detalhes do pedido |
| GET | `/pedidos/novo` | Formulário para criar novo pedido |
| POST | `/pedidos` | Criar novo pedido |
| POST | `/pedidos/{id}/atualizar-status` | Atualizar status do pedido |
| POST | `/pedidos/{id}/deletar` | Deletar pedido |

## 📊 Banco de Dados

### Tabelas

#### livros
```sql
- id (PK)
- titulo
- autor
- descricao
- preco
- imagem_url
- estoque
- ativo
- data_criacao
- data_atualizacao
```

#### pedidos
```sql
- id (PK)
- numero_pedido (UNIQUE)
- nome_cliente
- email_cliente
- telefonecliente
- endereco
- status (ENUM)
- total_pedido
- data_criacao
- data_atualizacao
```

#### itens_pedido
```sql
- id (PK)
- pedido_id (FK)
- livro_id (FK)
- quantidade
- preco_unitario
- subtotal
```

## 🎨 Interface

A interface foi desenvolvida com **Bootstrap 5** e segue um design responsivo e profissional:

- **Navbar**: Navegação principal com links para Início, Catálogo, Pedidos e Novo Pedido
- **Página Inicial**: Hero section com CTA e livros em destaque
- **Catálogo**: Grid de livros com informações de preço e estoque
- **Novo Pedido**: Formulário completo com seleção de livros e cálculo automático
- **Listar Pedidos**: Tabela com busca e filtros
- **Detalhes do Pedido**: Visualização completa com opção de atualizar status ou deletar

## 🔍 Funcionalidades Detalhadas

### 1. Criação de Pedido
- Formulário com dados do cliente (nome, email, telefone, endereço)
- Seleção dinâmica de livros com quantidade
- Cálculo automático de subtotais e total
- Geração automática de número único do pedido

### 2. Listagem e Busca
- Visualização de todos os pedidos em tabela responsiva
- Busca por número do pedido, nome do cliente ou email
- Filtros por status
- Ordenação por data de criação (mais recente primeiro)

### 3. Gerenciamento de Status
- Status disponíveis: Pendente, Confirmado, Enviado, Entregue, Cancelado
- Atualização de status em tempo real
- Badges coloridas para melhor visualização

### 4. Catálogo de Livros
- Listagem dinâmica de livros ativos
- Informações de preço, autor e estoque
- Imagens de capa dos livros
- Filtro de livros em destaque na página inicial

## 🧪 Testes

Para executar os testes unitários:

```bash
mvn test
```

## 📝 Notas Importantes

1. **Configuração do Banco de Dados**: Certifique-se de que o MySQL está rodando e a senha está correta no `application.properties`
2. **Porta Padrão**: A aplicação roda na porta 8080 por padrão
3. **Dados Iniciais**: O arquivo `schema.sql` já inclui dados de exemplo (10 livros e 3 pedidos)
4. **Validação**: O formulário de novo pedido valida campos obrigatórios no cliente e servidor

## 🐛 Troubleshooting

### Erro: "Connection refused"
- Verifique se o MySQL está rodando
- Confirme as credenciais no `application.properties`

### Erro: "Database not found"
- Execute o arquivo `database/schema.sql` para criar o banco de dados

### Erro: "Port already in use"
- Mude a porta em `application.properties`: `server.port=8081`

## 📄 Licença

Este projeto é fornecido como material educacional para fins de aprendizado.

## 👨‍💻 Autor

Desenvolvido como projeto integrador para demonstrar competências em **Spring Boot**, **Thymeleaf** e **MySQL**.

## 📞 Suporte

Para dúvidas ou problemas, verifique:
1. Se o MySQL está rodando
2. Se as credenciais estão corretas
3. Se o arquivo `schema.sql` foi executado
4. Os logs da aplicação em `logs/`

---

**Versão**: 1.0.0  
**Última Atualização**: Março 2025
